from google.appengine.ext import ndb
from Question import Question


class Teacher(ndb.Model):
    Username = ndb.StringProperty()
    Password = ndb.StringProperty()
    Account = ndb.StringProperty()
    QuestionsOld = ndb.StructuredProperty(Question, repeated=True)
    QuestionsNew = ndb.StructuredProperty(Question, repeated=True)
    Name = ndb.StringProperty()
