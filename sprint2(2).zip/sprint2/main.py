#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import webapp2
import os
import jinja2
from google.appengine.ext import ndb
from FAQ import FAQ
from Student import Student
from Question import Question
from teacher import Teacher

FAQ = FAQ()
FAQ.Answers_open()
FAQ.Questions_open()

Questions = FAQ.questions
Answers = FAQ.answers

global name
name = "undefined"
global user
subjects = []
questions = []
answers = []
theQuestion = ""
theAnswer = ""
msglist = []

JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__) + '/page'))

student = Student(Username="peter", Password="12345", Account="student", Name="Peter")
studentKey = student.put()
teacher = Teacher(Username="rob", Password="abc", Account="teacher", Name="Robert")
teachKey = teacher.put()

students = list(Student.query().fetch())


class LoginHandler(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('LoginSpr1.html')
        self.response.write(template.render())

    def post(self):
        global user
        user = self.request.get("username")
        pword = self.request.get("password")
        # teachers = Teacher.query().fetch()
        # we have 2 different types of accounts to login as now
        # need to check account of the username entered first to know
        # which list to loop through to check
        # if querying by username returns 0 in both send to loginFail page
        #
        # OR try to append both lists and loop through one list looking
        # for username and password since both account contain those same datafields
        # users = students + teachers
        for stud in students:
            if (stud.Username == user):
                self.response.write("username correct")
                if (stud.Password == pword):
                    self.response.write("password correct")
                    self.redirect("/student")
                else:
                    self.redirect("/fail")
            else:
                self.redirect("/fail")


##################################STUDENT###############################				
class StudentHandler(webapp2.RequestHandler):
    def get(self):
        global user
        template = JINJA_ENVIRONMENT.get_template('StudentsPage.html')
        my_user = Student.query(Student.Username == user).fetch()
        self.response.write(template.render({
            'user': my_user[0].Username
        }))


class MessageHandler(webapp2.RequestHandler):
    def post(self):
        global user
        subj = self.request.get('subject')
        msg = self.request.get('question')
        question = Question(S=subj, Q=msg)
        question.put()
        my_user = Student.query(Student.Username == user).fetch()
        if not my_user:
            self.response.write("can't find user")
        else:
            my_user[0].Questions.append(question)
            if not my_user[0].Questions:
                self.response.write("cant append yet")
            else:
                # course = self.request.get('classes')
                # subjects.append("""<u style="color:black;">""" + course + """:</u>""" + " " + subj)
                self.response.write("The message was successfully sent..." + '</br>')
                self.response.write("You will be redirected to the student page in 5 seconds")
                self.response.write("""<head runat="server">
        <meta http-equiv="Refresh" content="5;url='/student'" />
    </head>""")


class InboxPageGet(webapp2.RequestHandler):
    def get(self):
        global user
        template = JINJA_ENVIRONMENT.get_template('inboxPage.html')
        my_user = Student.query(Student.Username == user).fetch()
        if not my_user:
            self.response.write("there is no user")

        if not my_user[0].Questions:
            self.response.write("list questions is empty")
        else:
            slist = []
            qlist = []
            for i in my_user[0].Questions:
                slist.append(i.S)
                qlist.append(i.Q)
            template_values = {
                's': slist,
                'q': qlist,
                # 'a': answers,
                'user': my_user[0].Username
            }
            self.response.write(template.render(template_values))


class InboxPageMsg(webapp2.RequestHandler):
    def get(self):
        pass

    def post(self):
        template = JINJA_ENVIRONMENT.get_template('inboxPage.html')
        val = self.request.get("subjectButton")
        theQuestion = questions[int(val) - 1]

        if (int(val)) <= len(answers):
            theAnswer = answers[int(val) - 1]
        else:
            theAnswer = ""

        template_values = {
            's': subjects,
            'ta': theAnswer,
            'a': answers,
            'tq': theQuestion,
            'user': name
        }
        self.response.write(template.render(template_values))


##################################TEACHER###############################
class Teacher(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('Teacher.html')
        template_values = {
            's': subjects,
            'user': name
        }
        self.response.write(template.render(template_values))

    def post(self):
        template = JINJA_ENVIRONMENT.get_template('Teacher.html')
        val = self.request.get("subjectButton")
        theQuestion = questions[int(val) - 1]
        template_values = {
            's': subjects,
            'tq': theQuestion,
            'user': name
        }
        self.response.write(template.render(template_values))


class AnsHandler(webapp2.RequestHandler):
    def get(self):
        answer = self.request.get('myTextBox')
        answers.append(answer)
        self.redirect('/teacher')


####################################FAQ################################
class FAQ(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('FAQ.html')
        self.response.write(template.render({
            'Q': Questions,
            'A': Answers
        }))


####################################clear###############################
class ClearHandler(webapp2.RequestHandler):
    def get(self):
        # users = list(User.query())
        question = list(Question.query())
        # for u in users:
        #    u.key.delete()
        for i in question:
            i.key.delete()
        self.redirect('/student')


app = webapp2.WSGIApplication([
    ('/', LoginHandler),
    ('/student', StudentHandler),
    ('/teacher', Teacher),
    ('/teacherAns', AnsHandler),
    ('/inbox', InboxPageGet),
    ('/send', MessageHandler),
    ('/inboxMsg', InboxPageMsg),
    ('/clear', ClearHandler),
    ('/faq', FAQ)
], debug=True)
