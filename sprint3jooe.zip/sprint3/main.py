#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import webapp2
import os
import urllib
import jinja2

from google.appengine.ext import ndb
from Student import Student
from FAQ import FAQ
from Question import Question
from teacher import Teacher
import datetime

# Need to create some users initally to test login
# from csv eventually...  hardcoded for now

# question = Question.query().fetch()
# for q in question:
# q.key.delete()

# students = Student.query().fetch()
# for s in students:
# s.key.delete()

# teachers = Teacher.query().fetch()
# for t in teachers:
# t.key.delete()

# student = Student(Username="adi", Password = "qwe", Account = "student", Name = "Adi")
# AdiKey = student.put()
# student = Student(Username= "peter", Password = "12345", Account = "student", Name = "Peter")
# studentKey = student.put()
# teacher = Teacher(Username = "rob", Password = "abc", Account = "teacher", Name = "Robert")
# teachKey = teacher.put()


# f1 = FAQ(Question="How long is the semester?", Answer="The semester is 15 weeks long")
# faq1 = f1.put()
# f2 = FAQ(Question="Are the Lions and Vikings really the best teams in the NFC North division right now?",
         # Answer="Sadly yes")
# faq21 = f2.put()
# f3 = FAQ(Question="How long is the semester?", Answer="The semester is 15 weeks long")
# faq3 = f3.put()
# f4 = FAQ(Question="How long is the semester?", Answer="The semester is 15 weeks long")
# faq4 = f4.put()
# f5 = FAQ(Question="How would you like us to address you?", Answer="You may call me Mister Doctor")
# faq5 = f5.put()

JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__) + '/page'))


class MainHandler(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('LoginSpr1.html')
        self.response.write(template.render())

    def post(self):
        user = self.request.get("username")
        pword = self.request.get("password")

        students = Student.query(Student.Username == user).fetch()
        teachers = Teacher.query(Teacher.Username == user).fetch()

        if (len(students) > 0):
            userCur = students[0]
            if (userCur.get_password() == pword):
                self.response.set_cookie('name', userCur.Username, path='/')
                self.redirect("/student")
            else:
                self.redirect("/fail")
        elif (len(teachers) > 0):
            userCur = teachers[0]
            if (userCur.get_password() == pword):
                self.response.set_cookie('name', userCur.Username, path='/')
                self.redirect("/teacher")
            else:
                self.redirect("/fail")
        else:
            self.redirect("/fail")


class Fail(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('LoginInvalid.html')
        self.response.write(template.render())

    def post(self):
        user = self.request.get("username")
        pword = self.request.get("password")

        students = Student.query(Student.Username == user).fetch()
        teachers = Teacher.query(Teacher.Username == user).fetch()

        if (len(students) > 0):
            userCur = students[0]
            if (userCur.get_password() == pword):
                self.response.set_cookie('name', userCur.Username, path='/')
                self.redirect("/student")
            else:
                self.redirect("/fail")
        elif (len(teachers) > 0):
            userCur = teachers[0]
            if (userCur.get_password() == pword):
                self.response.set_cookie('name', userCur.Username, path='/')
                self.redirect("/teacher")
            else:
                self.redirect("/fail")
        else:
            self.redirect("/fail")


################################################################################				

class StudentHandler(webapp2.RequestHandler):
	def get(self):
		uname = self.request.cookies.get("name")
		if(not uname):
			self.redirect("/")
		else:
			students = Student.query(Student.Username == uname).fetch()
			student1 = students[0]

			template = JINJA_ENVIRONMENT.get_template('StudentsPage.html')
			self.response.write(template.render({
				'user': student1.Name
			}))


class MessageHandler(webapp2.RequestHandler):
	def post(self):
		uname = self.request.cookies.get("name")
		if(not uname):
			self.redirect("/")
		else:
			students = Student.query(Student.Username == uname).fetch()
			student1 = students[0]

			subj = self.request.get('subject')
			msg = self.request.get('question')
			course = self.request.get('classes')
			if (course == "course 1"):
				teacherTo = "rob"
			elif (course == "course 2"):
				teacherTo = "mike"
			question = Question(S=subj, Q=msg, A="", From=student1.Username, To=teacherTo)
			question.put()

			self.response.write("The message was successfully sent..." + '</br>')
			self.response.write("You will be redirected to the student page in 3 seconds")
			self.response.write("""<head runat="server">
			<meta http-equiv="Refresh" content="3;url='/student'" />
			</head>""")


class InboxPageGet(webapp2.RequestHandler):
	def get(self):
		uname = self.request.cookies.get("name")
		if(not uname):
			self.redirect("/")
		else:
			students = Student.query(Student.Username == uname).fetch()
			student1 = students[0]

			template = JINJA_ENVIRONMENT.get_template('inboxPage.html')

       
			subList = []
			QuestList = []
			AnswList = []
			datelist = []
			questions = Question.query(Question.From == uname).fetch()

			for i in questions:
				subList.append(i.S)
				QuestList.append(i.Q)
				datelist.append(i.date)
				if (i.A == None) or (i.A == ""):
					AnswList.append("")
				else:
					AnswList.append(i.A)
				
			template_values = {
				'd': datelist,
				's': subList,
				'q': QuestList,
				'a': AnswList,
				'user': student1.Name
			}

			self.response.write(template.render(template_values))

      
class InboxPageMsg(webapp2.RequestHandler):
	def get(self):
		pass

	def post(self):
		uname = self.request.cookies.get("name")
		if(not uname):
			self.redirect("/")
		else:
			template = JINJA_ENVIRONMENT.get_template('inboxPage.html')
			students = Student.query(Student.Username == uname).fetch()
			student1 = students[0]
			subj = self.request.get("subjectButton")
			slist = []
			qlist = []
			alist = []
			datelist = []

			questions = Question.query(Question.From == uname).fetch()
			the_question = "empty"
			the_answer = "empty"
			for i in questions:
				slist.append(i.S)
				qlist.append(i.Q)
				alist.append(i.A)
				datelist.append(i.date)

			the_question = qlist[int(subj)]
			the_answer = alist[int(subj)]
	
			color = "#9b9b9b"
			if the_answer:
				color = "green"

			template_values = {
				'd': datelist,
				's': slist,
				'q': qlist,
				'tq': the_question,
				'ta': the_answer,
				'user': student1.Name,
				'color': color
			}
			self.response.write(template.render(template_values))


class TeacherHandler(webapp2.RequestHandler):
	def get(self):
		uname = self.request.cookies.get("name")
		if(not uname):
			self.redirect("/")
		else:
			teachers = Teacher.query(Teacher.Username == uname).fetch()
			teacher1 = teachers[0]
			faq = FAQ.query().fetch()
			template = JINJA_ENVIRONMENT.get_template('Teacher.html')

			slist = []
			qlist = []

			questions = Question.query(Question.To == uname).fetch()
			for i in questions:
				slist.append(i.S)
				qlist.append(i.Q)
       
			template_values = {
				'faq': faq,
				's': slist,
				'q': qlist,
				'user': teacher1.Name
			}
			self.response.write(template.render(template_values))

	def post(self):
		uname = self.request.cookies.get("name")
		if(not uname):
			self.redirect("/")
		else:
			teachers = Teacher.query(Teacher.Username == uname).fetch()
			teacher1 = teachers[0]
			template = JINJA_ENVIRONMENT.get_template('Teacher.html')
			questions = Question.query(Question.To == uname).fetch()
			subj = self.request.get("subjectButton")
			faq = FAQ.query().fetch()

			slist = []
			qlist = []

			the_question = "empty"
			for i in questions:
				slist.append(i.S)
				qlist.append(i.Q)

			the_question = qlist[int(subj)]
			self.response.set_cookie('question', the_question, path='/')

			template_values = {
				'faq': faq,
				's': slist,
				'tq': the_question,
				'user': teacher1.Name
			}
			self.response.write(template.render(template_values))



class TeacherSendAnswer(webapp2.RequestHandler):
	def get(self):
		uname = self.request.cookies.get("name")
		if(not uname):
			self.redirect("/")
		else:
			question_cookie = self.request.cookies.get("question")
			zeroQ = Question.query(Question.To == uname).fetch()

			faq = self.request.get('faqQ')
			num_of_question = "#Q" + str(faq)

			if (len(zeroQ) > 0):
				questions = Question.query(Question.Q == question_cookie).fetch()
				question = questions[0]
				answer = self.request.get("myTextBox")
				checkBox = self.request.get('faqCheckBox')
				if checkBox:
					answer += '<br> <b style="color:red;" >you can find the answer in </b> <a href="/faq' + num_of_question + '" target="_blank">' + 'Q' + str(
						faq) + '</a> <b style="color:red;">on the FAQ page</b>'
				question.A = answer
				question.put()
				self.response.write("The answer was successfully sent..." + '</br>')
				self.response.write("You will be redirected to the teacher page in 3 seconds")
				self.response.write("""<head runat="server">
				<meta http-equiv="Refresh" content="3;url='/teacher'" />
				</head>""")
			else:
				self.redirect('/teacher')


class FaqDisplay(webapp2.RequestHandler):
    def get(self):
        fQ = FAQ.query().fetch()
        qList = []
        template = JINJA_ENVIRONMENT.get_template('FAQ.html')
        aList = []
        for faq in fQ:
            qList.append(faq.Question)
            aList.append(faq.Answer)


        template_values = {
            'Q': qList,
            'A': aList
        }
        self.response.write(template.render(template_values))


class CreateUser(webapp2.RequestHandler):
	def get(self):
		uname = self.request.cookies.get("name")
		if(not uname):
			self.redirect("/")
		else:
			teachers = Teacher.query(Teacher.Username == uname).fetch()
			teacher1 = teachers[0]
			template = JINJA_ENVIRONMENT.get_template('user.html')
			template_values = {
				'user': teacher1.Name
			}
			self.response.write(template.render(template_values))
			
	def post(self):
		uname = self.request.cookies.get("name")
		teachers = Teacher.query(Teacher.Username == uname).fetch()
		teacher1 = teachers[0]
		studinfo = self.request.get("creatUserBox")
		results = teacher1.create_students(studinfo)
		self.response.write("Creating Students... </br></br>")
		self.response.write("Students Created: </br>")
		for i in results[0]:
			self.response.write("""<li> """+ i + """</li>""")
		
		self.response.write("</br>Students not created(Identical Username): </br>")
		for i in results[1]:
			self.response.write("""<li> """+ i + """</li>""")
		self.response.write(""" <a href = "/cUser"> Continue </a> """)
	
class LogOutHandler(webapp2.RequestHandler):
	def get(self):
		uname = self.request.cookies.get("name")
		if(not uname):
			self.redirect("/")
		else:
			students = Student.query(Student.Username == uname).fetch()
			teachers = Teacher.query(Teacher.Username == uname).fetch()

			if (len(students) > 0):
				userCur = students[0]
			if (len(teachers) > 0):
				userCur = teachers[0]
				
			self.response.delete_cookie("name")
			self.response.write(userCur.Name + " logged out" + '</br>')
			self.response.write("Redirecting to Login in 3 seconds")
			self.response.write("""<head runat="server">
			<meta http-equiv="Refresh" content="3;url='/'" />
			</head>""")
	
class CreateFAQ(webapp2.RequestHandler):
	def get(self):
		uname = self.request.cookies.get("name")
		if(not uname):
			self.redirect("/")
		else:
			teachers = Teacher.query(Teacher.Username == uname).fetch()
			teacher1 = teachers[0]
			template = JINJA_ENVIRONMENT.get_template('CreatFAQ.html')
			template_values = {
				'user': teacher1.Name
			}
			self.response.write(template.render(template_values))
	
	def post(self):
		uname = self.request.cookies.get("name")
		teachers = Teacher.query(Teacher.Username == uname).fetch()
		teacher1 = teachers[0]
		studinfo = self.request.get("creatFaqBox")
		results = teacher1.addFAQ(studinfo)
		self.response.write("Creating new frequently asked question(s)... </br></br>")
		self.response.write("FAQ Created: </br>")
		for i in results:
			self.response.write("""<li> """+ i + """</li>""")
		
		self.response.write(""" <a href = "/creatFaq"> Continue </a> """)		
	
app = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/student', StudentHandler),
    ('/teacher', TeacherHandler),
    ('/fail', Fail),
    ('/inbox', InboxPageGet),
    ('/cUser', CreateUser),
    ('/teacherAns', TeacherSendAnswer),
    ('/inboxMsg', InboxPageMsg),
    ('/send', MessageHandler),
    ('/faq', FaqDisplay),
	('/logout', LogOutHandler),
	('/creatFaq', CreateFAQ)
], debug=True)
