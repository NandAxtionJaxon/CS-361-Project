from google.appengine.ext import ndb
from Question import Question
from Student import Student
from FAQ import FAQ
class Teacher(ndb.Model):

	Username = ndb.StringProperty()
	Password = ndb.StringProperty()
	Account = ndb.StringProperty()
	Questions = ndb.StructuredProperty(Question, repeated = True)
	#QuestionsOld = ndb.StructuredProperty(Question, repeated = True)
	#QuestionsNew = ndb.StructuredProperty(Question, repeated = True)
	Name = ndb.StringProperty()
	
	
	def get_password(self):
		return self.Password
	
	
	def create_students(self, studinfo):
		username = []
		name = []
		password = []
		count = 0
		studentNoSpace = studinfo.replace(" ", "")
		studsplitcolon = studentNoSpace.split(";")
		for s in studsplitcolon:
			studentinfo = s.split(",")
			name.append(studentinfo[0])
			username.append(studentinfo[1])
			password.append(studentinfo[2])
			count+=1
		
		CreatedStudents= []
		Failed = []
		results = []
		for i in range(count):
			students = Student.query(Student.Username == username[i]).fetch()
			if not students:
				student = Student(Username= username[i], Password = password[i], Account = "student", Name = name[i])
				newstud = student.put()
				CreatedStudents.append("Name: " + name[i] + ", Username: " + username[i] + ", Password: " + password[i] + "")
			else:
				Failed.append("Name: " + name[i] + ", Username: " + username[i] + ", Password: " + password[i] + "")
		
		results.append(CreatedStudents)
		results.append(Failed)
		return results
		
	def addFAQ(self, newFaq):
		resultslist = []
		question = []
		answer = []
		count = 0
		
		Faqsplitcolon = newFaq.split(";")
		
		for f in Faqsplitcolon:
			Faqinfo = f.split(",")
			question.append(Faqinfo[0])
			answer.append(Faqinfo[1])
			count +=1
			
		for i in range(count):
			f1 = FAQ(Question=question[i], Answer=answer[i])
			faq1 = f1.put()
			resultslist.append("Question: " + question[i] + ", Answer: " + answer[i] + "")
		
		return resultslist

	
	