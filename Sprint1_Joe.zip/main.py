#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import webapp2
import os
import urllib
import jinja2
from login import Login

JINJA_ENVIRONMENT = jinja2.Environment(
			loader = jinja2.FileSystemLoader(os.path.dirname(__file__)+'/page'))




			
class MainHandler(webapp2.RequestHandler):
	def get(self):
		template = JINJA_ENVIRONMENT.get_template('LoginSpr1.html')
		#self.response.write(Username)
		#self.response.write(password)
		#self.response.write(account)
		#name = "jacks429"
		#pasw = "12345"
		#if(name == Username[0]):
		#	self.response.write("1 worked")
		#	if(pasw == password[0]):
		#		self.response.write("2 worked")
		
		self.response.write(template.render())
		
	def post(self):	
		self.login = Login();
		self.login.login_open()
		user = self.request.get("username")
		pword = self.request.get("password")
		for i in range(self.login.count):
			if(user == self.login.Username[i]):
				if(pword == self.login.password[i]):
					if(self.login.account[i] == "student"):
						self.redirect("/student")
					elif(self.login.account[i] == "teacher"):
						self.redirect("/teacher")
	
#class Login(webapp2.RequestHandler):	
#	def post(self):
		#self.response.write(self.request.get("username"))
		#self.response.write(self.request.get("password"))
		
						#template = JINJA_ENVIRONMENT.get_template('Student.html')
			#else:
		
						#self.response.write(template.render())
					#if(account[i] == "teacher"):
					
					#self.redirect('/student')
			
				
		
class Student(webapp2.RequestHandler):
	def get(self):
		template = JINJA_ENVIRONMENT.get_template('Student.html')
		self.response.write(template.render())
#class LogIn(webapp2.RequestHandler):
#	def get(self):
#	pass

class Teacher(webapp2.RequestHandler):
	def get(self):
		template = JINJA_ENVIRONMENT.get_template('Teacher.html')
		self.response.write(template.render())
		
app = webapp2.WSGIApplication([
    ('/', MainHandler),
#	('/login', Login),
	('/student', Student),
	('/teacher', Teacher)
	#('/loginF', LoginInvalid)
], debug=True)
