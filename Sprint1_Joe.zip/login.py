class Login(object):
	
	def __init__(self):
		self.Username = []
		self.password= []
		self.account = []
		self.count = 0
		
	def login_open(self):
	#global Username
	#global password
	#global account
	#global count
		with open('LoginInfo.txt') as f:
			for line in f:
				temp = line.split(",")
				self.Username.append(temp[0])
				self.password.append(temp[1])
				self.account.append(temp[2])
				self.count = self.count+1
		
		return