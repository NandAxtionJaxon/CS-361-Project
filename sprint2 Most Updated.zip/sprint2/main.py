#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import webapp2
import os
import urllib
import jinja2
from google.appengine.ext import ndb
from Student import Student
from Question import Question
from teacher import Teacher
#Need to create some users initally to test login
#from csv eventually...  hardcoded for now

# student = Student(Username="adi", Password = "qwe", Account = "student", Name = "Adi")
# AdiKey = student.put()
# student = Student(Username= "peter", Password = "12345", Account = "student", Name = "Peter")
# studentKey = student.put()
# teacher = Teacher(Username = "rob", Password = "abc", Account = "teacher", Name = "Robert")
# teachKey = teacher.put()

JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__) + '/page'))



class MainHandler(webapp2.RequestHandler):
	def get(self):
		template = JINJA_ENVIRONMENT.get_template('LoginSpr1.html')
		self.response.write(template.render())
		
	def post(self):
		user = self.request.get("username")
		pword = self.request.get("password")
		
		students = Student.query(Student.Username == user).fetch()
		teachers = Teacher.query(Teacher.Username == user).fetch()
		
		if(len(students) > 0):
			userCur = students[0]
			if(userCur.get_password() == pword):
				self.response.set_cookie('name', userCur.Username, path='/')
				self.redirect("/student")
			else:
				self.redirect("/fail")
		elif(len(teachers) > 0):
			userCur = teachers[0]
			if(userCur.get_password() == pword):
				self.response.set_cookie('name', userCur.Username, path='/')
				self.redirect("/teacher")
			else:
				self.redirect("/fail")
		else:
			self.redirect("/fail")
				
				
		#we have 2 different types of accounts to login as now 
		#need to check account of the username entered first to know
		#which list to loop through to check
		#if querying by username returns 0 in both send to loginFail page
		#
		#OR try to append both lists and loop through one list looking
		#for username and password since both account contain those same datafields
		#users = students + teachers
		
class Fail(webapp2.RequestHandler):
	def get(self):
		template = JINJA_ENVIRONMENT.get_template('LoginInvalid.html')
		self.response.write(template.render())
		
	def post(self):
		user = self.request.get("username")
		pword = self.request.get("password")
		
		students = Student.query(Student.Username == user).fetch()
		teachers = Teacher.query(Teacher.Username == user).fetch()
		
		if(len(students) > 0):
			userCur = students[0]
			if(userCur.get_password() == pword):
				self.response.set_cookie('name', userCur.Username, path='/')
				self.redirect("/student")
			else:
				self.redirect("/fail")
		elif(len(teachers) > 0):
			userCur = teachers[0]
			if(userCur.get_password() == pword):
				self.response.set_cookie('name', userCur.Username, path='/')
				self.redirect("/teacher")
			else:
				self.redirect("/fail")
		else:
			self.redirect("/fail")
				
################################################################################				
		
class StudentHandler(webapp2.RequestHandler):			
	def get(self):
		
		uname = self.request.cookies.get("name")
		students = Student.query(Student.Username == uname).fetch()
		student1 = students[0]
	
		template = JINJA_ENVIRONMENT.get_template('StudentsPage.html')
		self.response.write(template.render({
            'user': student1.Username
        }))
		

	
	
	
class MessageHandler(webapp2.RequestHandler):
	def post(self): 
		uname = self.request.cookies.get("name")
		students = Student.query(Student.Username == uname).fetch()
		student1 = students[0]
		
		subj = self.request.get('subject')
		msg = self.request.get('question')
		course = self.request.get('classes')
		if(course == "course 1"):
			teacherTo = "rob"
		question = Question(S=subj, Q=msg, From = student1.Username, To = teacherTo)
		teachers = Teacher.query(Teacher.Username == teacherTo).fetch()
		teacher1 = teachers[0]
		#q_key = question.put()
		
		
		if len(students) < 1:
			self.response.write("can't find user")
		else:
			student1.Questions.append(question)
			teacher1.Questions.append(question)
			teacher1.put()
			student1.put()
			if len(student1.Questions)< 1:
				self.response.write("cant append yet")
			else:
                
                # subjects.append("""<u style="color:black;">""" + course + """:</u>""" + " " + subj)
				self.response.write("The message was successfully sent..." + '</br>')
				self.response.write("You will be redirected to the student page in 3 seconds")
				self.response.write("""<head runat="server">
		<meta http-equiv="Refresh" content="3;url='/student'" />
	</head>""")
	
	
class InboxPageGet(webapp2.RequestHandler):
	def get(self):
		
		uname = self.request.cookies.get("name")
		students = Student.query(Student.Username == uname).fetch()
		student1 = students[0]
		
		template = JINJA_ENVIRONMENT.get_template('inboxPage.html')
		
		if len(students) < 1:
			self.response.write("there is no user")
		if len(student1.Questions) < 1:
			self.response.write("list questions is empty")
		else:
			slist = []
			qlist = []
			for i in student1.Questions:
				slist.append(i.S)
				qlist.append(i.Q)
			template_values = {
				's': slist,
				'q': qlist,
				# 'a': answers,
				'user': student1.Username
			}
			self.response.write(template.render(template_values))
	
	
class TeacherHandler(webapp2.RequestHandler):			
	def get(self):
	
		uname = self.request.cookies.get("name")
		teachers = Teacher.query(Teacher.Username == uname).fetch()
		self.response.write(teachers[0].Username)
		self.response.write(teachers[0].Name)
		for i in teachers[0].Questions:
			self.response.write(i.Q)
			self.response.write(i.A)
			self.response.write(i.S)
		
		
		

app = webapp2.WSGIApplication([
    ('/', MainHandler),
	('/student', StudentHandler),
	('/teacher', TeacherHandler),
	('/fail', Fail),
	('/inbox', InboxPageGet),
	('/send', MessageHandler)
    #('/inboxMsg', InboxPageMsg)
], debug=True)
