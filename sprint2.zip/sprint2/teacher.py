from google.appengine.ext import ndb
from Question import Question
class Teacher(ndb.Model):

	Username = ndb.StringProperty()
	Password = ndb.StringProperty()
	Account = ndb.StringProperty()
	Questions = ndb.StructuredProperty(Question, repeated = True)
	#QuestionsOld = ndb.StructuredProperty(Question, repeated = True)
	#QuestionsNew = ndb.StructuredProperty(Question, repeated = True)
	Name = ndb.StringProperty()
	
	
		
	def get_username(self):
		return self.Username
		
	def get_password(self):
		return self.Password
	
	def get_account(self):
		return self.Account
			
	@classmethod
	def get_questions(self):
		questions = self.Questions
		return questions

	def get_name(self):
		return Name