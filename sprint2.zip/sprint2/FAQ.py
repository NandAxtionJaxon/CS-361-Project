class FAQ(object):

	
	def __init__ (self):
		self.questions = []
		self.answers = []
		self.count = 0
		
	def Answers_open(self):
		with open('answers.txt') as f:
			for line in f:
				self.answers.append(line);
				
	def Questions_open(self):
		with open('questions.txt') as f:
			for line in f:
				self.questions.append(line);
				self.count = self.count + 1;
