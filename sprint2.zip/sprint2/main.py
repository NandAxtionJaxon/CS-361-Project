#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import webapp2
import os
import urllib
import jinja2
from google.appengine.ext import ndb
from Student import Student
from Question import Question
from teacher import Teacher
#Need to create some users initally to test login
#from csv eventually...  hardcoded for now



#student = Student(Username= "peter", Password = "12345", Account = "student", Name = "Peter")
#studentKey = student.put()
#teacher = Teacher(Username = "rob", Password = "abc", Account = "teacher", Name = "Robert")
#teachKey = teacher.put()

JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__) + '/page'))



class MainHandler(webapp2.RequestHandler):
	def get(self):
		template = JINJA_ENVIRONMENT.get_template('LoginSpr1.html')
		self.response.write(template.render())
		
	def post(self):
		user = self.request.get("username")
		pword = self.request.get("password")
		students = Student.query().fetch()
		teachers = Teacher.query().fetch()
		#we have 2 different types of accounts to login as now 
		#need to check account of the username entered first to know
		#which list to loop through to check
		#if querying by username returns 0 in both send to loginFail page
		#
		#OR try to append both lists and loop through one list looking
		#for username and password since both account contain those same datafields
		#users = students + teachers
		for stud in students:
			if(stud.Username == user):
				#self.response.write("username correct")
				if(stud.Password == pword):
					#self.response.write("password correct")
					self.redirect("/student")
				else:
					self.redirect("/fail")
			else:
				self.redirect("/fail")
				
		
class StudentHandler(webapp2.RequestHandler):			
	def get(self):
		#user = studentKey.get()
		#self.response.write(user.Username)
		#self.response.write(studentKey)
		self.response.write("It worked")

		
class Fail(webapp2.RequestHandler):			
	def get(self):
		self.response.write("No")		
		
app = webapp2.WSGIApplication([
    ('/', MainHandler),
	('/student', StudentHandler),
	('/fail', Fail)
], debug=True)
