from google.appengine.ext import ndb
from Question import Question
class Student(ndb.Model):

	Username = ndb.StringProperty()
	Password = ndb.StringProperty()
	Account = ndb.StringProperty()
	Question = ndb.StructuredProperty(Question, repeated = True)
	Name = ndb.StringProperty()
		
		
	
	@classmethod	
	def get_username(self):
		return Username
		
	@classmethod
	def get_password(self):
		return self.Password
	
	@classmethod
	def get_account(self):
		return self.Account
		
	@classmethod	
	def get_questions(self):
		questions = Questions.query().fetch()
		return questions
	
	@classmethod
	def get_name(self):
		return Name