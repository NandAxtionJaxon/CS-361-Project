import unittest
import sys

sys.path.insert(1, "C:\Program Files (x86)\Google\google_appengine")
sys.path.insert(1, "C:\Program Files (x86)\Google\google_appengine\lib\yaml\lib")
sys.path.insert(1, 'C:\Users\Musaed\Desktop\sprint2')
from Student import Student
from Teacher import Teacher
from Question import Question
from google.appengine.ext import ndb


class QA(unittest.TestCase):
    def setUp(self):
        self.student = Student(Username='Jo', Password='123', Account='student', Name='Jo')
        self.teacher = Teacher(Username='Robert', Password='abc', Account='teacher', Name='Robert')

    def test_studentInfo(self):
        self.assertEqual(self.student.Username, 'Jo')
        self.assertEqual(self.student.Password, '123')
        self.assertEqual(self.student.Account, 'student')
        self.assertEqual(self.student.Name, 'Jo')

    def test_teacher(self):
        self.assertEqual(self.teacher.Username, 'Robert')
        self.assertEqual(self.teacher.Password, 'abc')
        self.assertEqual(self.teacher.Account, 'teacher')
        self.assertEqual(self.teacher.Name, 'Robert')

    def test_question(self):
        self.question = Question()
        self.question.Q = 'When is the final exam?'
        self.question.A = 'We will never have one'
        self.student.Question.append(self.question)
        self.assertEqual(self.question.Q, 'When is the final exam?')
        self.assertEqual(self.question.A, 'We will never have one')


suite = unittest.TestLoader().loadTestsFromTestCase(QA)
unittest.TextTestRunner(verbosity=2).run(suite)
