from google.appengine.ext import ndb

class Question(ndb.Model):
	
	Q = ndb.StringProperty()
	A = ndb.StringProperty()
	S = ndb.StringProperty()
	From = ndb.StringProperty()
	To = ndb.StringProperty()