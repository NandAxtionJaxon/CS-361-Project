from google.appengine.ext import ndb
from Question import Question
class Student(ndb.Model):
	
	Username = ndb.StringProperty()
	Password = ndb.StringProperty()
	Account = ndb.StringProperty()
	Questions = ndb.StructuredProperty(Question, repeated = True)
	Name = ndb.StringProperty()
		
	
	
	def get_username(self):
		return self.Username
	
	def get_password(self):
		return self.Password

	def get_account(self):
		return self.Account
			
	def get_questions(self):
		questions = Questions.query().fetch()
		return questions
	
	def get_name(self):
		return Name