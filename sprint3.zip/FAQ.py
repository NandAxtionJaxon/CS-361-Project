from google.appengine.ext import ndb

class FAQ(ndb.Model):
	Question = ndb.StringProperty()
	Answer = ndb.StringProperty()