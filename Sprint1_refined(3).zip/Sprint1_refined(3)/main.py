#!/usr/bin/env python
#
# Copyright 2007 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import time
import webapp2
import random
import os
import urllib
import jinja2
from login import Login
from FAQ import FAQ

login = Login()
login.login_open()

FAQ = FAQ()
FAQ.Answers_open()
FAQ.Questions_open()

Questions = FAQ.questions
Answers = FAQ.answers

global name
name = "undefined"
subjects = []
questions = []
answers = []
theQuestion = ""
theAnswer = ""
msglist = []

JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__) + '/page'))


class LoginHandler(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('LoginSpr1.html')
        self.response.write(template.render())

    def post(self):
        user = self.request.get("username")
        pword = self.request.get("password")
        action = login.login_confirm(user, pword)
        if (action == "student"):
            global name
            name = user
            self.redirect("/student")
        if (action == "teacher"):
            global name
            name = user
            self.redirect("/teacher")
        if (action == "failed"):
            self.redirect("/loginF")


class LoginInvalid(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('LoginInvalid.html')
        self.response.write(template.render())

    def post(self):
        userF = self.request.get("username")
        pwordF = self.request.get("password")
        actionF = login.login_confirm(userF, pwordF)
        if (actionF == "student"):
            global name
            name = userF
            self.redirect("/student")
        if (actionF == "teacher"):
            global name
            name = userF
            self.redirect("/teacher")
        if (actionF == "failed"):
            self.redirect("/loginF")


##################################STUDENT###############################				
class Student(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('StudentsPage.html')
        self.response.write(template.render({
            'user': name
        }))


class MessageHandler(webapp2.RequestHandler):
    def post(self):
        subj = self.request.get('subject')
        msg = self.request.get('question')
        course = self.request.get('classes')
        subjects.append("""<u style="color:black;">""" + course + """:</u>""" + " " + subj)
        questions.append(msg)
        self.response.write("The message was successfully sent..." + '</br>')
        self.response.write("You will be redirected to the student page in 5 seconds")
        self.response.write("""<head runat="server">
        <meta http-equiv="Refresh" content="5;url='/student'" />
    </head>""")


class InboxPageGet(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('inboxPage.html')
        template_values = {
            's': subjects,
            'q': questions,
            'a': answers,
            'user': name

        }
        self.response.write(template.render(template_values))


class InboxPageMsg(webapp2.RequestHandler):
    def get(self):
        pass

    def post(self):
        template = JINJA_ENVIRONMENT.get_template('inboxPage.html')
        val = self.request.get("subjectButton")
        theQuestion = questions[int(val) - 1]
        theAnswer = answers[int(val)- 1]


        template_values = {
            's': subjects,
            'q': questions,
            'a': answers,
            'tq': theQuestion,
            'ta':theAnswer,
            'user': name
        }
        self.response.write(template.render(template_values))


##################################TEACHER###############################
class Teacher(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('Teacher.html')
        template_values = {
            's': subjects,
            'user': name
        }
        self.response.write(template.render(template_values))
    def post(self):
        template = JINJA_ENVIRONMENT.get_template('Teacher.html')
        answer = self.request.get("myTextBox")
        answers.append(answer)
        template_values = {
            's': subjects,
            'user': name
        }
        self.response.write(template.render(template_values))


class Teacherinbox(webapp2.RequestHandler):
    def get(self):
        pass
    def post(self):
        template = JINJA_ENVIRONMENT.get_template('Teacher.html')
        answer = self.request.get("myTextBox")
        answers.append(answer)
        val = self.request.get("subjectButton")
        theQuestion = questions[int(val) - 1]

        template_values = {
            's': subjects,
            'tq': theQuestion,
            'user': name
        }
        self.response.write(template.render(template_values))

class teacherHandler(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('Profile.html')
        self.response.write(template.render())


####################################FAQ################################
class FAQ(webapp2.RequestHandler):
    def get(self):
        template = JINJA_ENVIRONMENT.get_template('FAQ.html')
        self.response.write(template.render({
            'Q': Questions,
            'A': Answers
        }))


app = webapp2.WSGIApplication([
    ('/', LoginHandler),
    ('/student', Student),
    ('/teacher', Teacher),
    ('/teacherinbox', Teacherinbox),
    ('/loginF', LoginInvalid),
    ('/inbox', InboxPageGet),
    ('/send', MessageHandler),
    ('/inboxMsg', InboxPageMsg),
    ('/faq', FAQ)
], debug=True)
