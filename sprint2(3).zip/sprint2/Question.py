from google.appengine.ext import ndb


class Question(ndb.Model):
    key_name = ndb.StringProperty()
    S = ndb.StringProperty()
    Q = ndb.StringProperty()
    A = ndb.StringProperty()
    From = ndb.StringProperty()
    To = ndb.StringProperty()
