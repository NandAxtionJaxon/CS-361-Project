import csv
class Login(object):
	
	def __init__(self):
		self.Username = []
		self.password= []
		self.account = []
		self.count = 0
		
		


	def login_open(self):
		with open('LoginInfo.txt', 'r') as f:
			reader = csv.reader(f)
			temp = list(reader)
			self.Username.append(temp[0])
			self.password.append(temp[1])
			self.account.append(temp[2])
			self.count = self.count+1
		
		return
		
	def login_confirm(self, username, password):
		for i in range(self.count):
			if(username == self.Username[i] and password == self.password[i]):
				if(self.account[i] == "student"):
					return "student"
				else:
					return "teacher"
			else:
				return "failed"